# NÚMEROS PRIMOS

Este paquete es exclusivamente un ejercicio para **Fundamentos de Python**