
print("Paquete - subpaquete1 - módulo 1")


def funct():
    print("Soy la función")