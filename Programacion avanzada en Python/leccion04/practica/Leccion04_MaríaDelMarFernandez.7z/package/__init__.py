
import package.sub_package1.mod1 as mod1
from package.sub_package1.mod1 import funct as fncMod1
import package.sub_package1.mod2 as mod2
import package.sub_package2.mod3 as mod3
import package.sub_package2.mod4 as mod4