
import package as pk

pk.mod1
pk.fncMod1()
pk.mod2
pk.mod3
pk.mod4